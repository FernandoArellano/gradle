package com.denofprogramming.controller;

import com.denofprogramming.model.Course;

public interface CourseControllerInterface extends ControllerInterface<Course>{

}
