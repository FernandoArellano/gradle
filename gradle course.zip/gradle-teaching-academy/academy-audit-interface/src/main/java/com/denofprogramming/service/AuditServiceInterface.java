package com.denofprogramming.service;

import com.denofprogramming.model.AuditDetail;

public interface AuditServiceInterface extends ServiceInterface<AuditDetail>{

}
