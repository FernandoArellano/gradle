package com.denofprogramming.controller;

import com.denofprogramming.model.AuditDetail;

public interface AuditControllerInterface extends ControllerInterface<AuditDetail>{

}
