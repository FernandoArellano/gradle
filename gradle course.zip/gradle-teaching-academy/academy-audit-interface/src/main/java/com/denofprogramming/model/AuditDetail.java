package com.denofprogramming.model;

public class AuditDetail extends DomainObject {

}
