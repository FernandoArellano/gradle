package com.denofprogramming.controller;

import org.springframework.stereotype.Controller;

import com.denofprogramming.model.User;

@Controller
public class UserController implements UserControllerInterface{

	@Override
	public User read(User DomainObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User update(User DomainObject) {
		// TODO Auto-generated method stub
		return null;
	}

}
