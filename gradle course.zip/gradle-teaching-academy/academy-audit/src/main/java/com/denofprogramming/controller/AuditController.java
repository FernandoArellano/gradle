package com.denofprogramming.controller;

import com.denofprogramming.model.AuditDetail;

public class AuditController implements AuditControllerInterface{

	@Override
	public AuditDetail read(AuditDetail DomainObject) {		
		return null;
	}

	@Override
	public AuditDetail update(AuditDetail DomainObject) {
		return null;
	}

}
