package com.denofprogramming.repository;

import com.denofprogramming.model.AuditDetail;

public class AuditRepository implements AuditRepositoryInterface{

	@Override
	public AuditDetail read(AuditDetail domainObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AuditDetail update(AuditDetail domainObject) {
		// TODO Auto-generated method stub
		return null;
	}

}
