package com.denofprogramming.repository;

import com.denofprogramming.model.Registration;

public interface RegistrationRepositoryInterface extends RepositoryInterface<Registration>{

}
