package com.denofprogramming.service;

import com.denofprogramming.model.User;

public interface UserServiceInterface extends ServiceInterface<User>{

	
}
