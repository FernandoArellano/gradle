package com.denofprogramming.repository;

import com.denofprogramming.model.User;

public interface UserRepositoryInterface extends RepositoryInterface<User>{

}
