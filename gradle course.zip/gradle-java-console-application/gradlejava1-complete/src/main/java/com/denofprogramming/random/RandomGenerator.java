/**
 * 
 */
package com.denofprogramming.random;

/**
 * 
 */
public interface RandomGenerator
{

    String name();

    int generate();

}
